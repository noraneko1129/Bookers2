# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key ='3e061030852aae3766a2befef60a09b85fa0430b39c160f4d811ba35931ca859adeae59cf55967663f15c6e31f2f712d23025a3d7678c2afa373c1a5d5a4b963'